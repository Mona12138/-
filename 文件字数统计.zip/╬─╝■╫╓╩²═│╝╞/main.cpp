#include <stdio.h>
#include <stdlib.h>
using namespace std;
void Cin();//读取
void write();//写入
void statistic();//统计
void menu();//菜单

void menu()
{
        system("cls");
        system("title 欢迎使用统计文本小程序");//控制窗口显示标题内容
        puts("\n\n\t********欢迎使用学生信息管理系统********");
        puts("\t*                                      *");
        puts("\t*                                      *");
        puts("\t*            1.读取文件                *");
        puts("\t*            2.更新文件内容            *");
        puts("\t*            3.  统计                  *");
        puts("\t*            4.退出系统                *");
        puts("\t*                                      *");
        puts("\t****************************************");
        printf("\n\t请输入编号(0~4)使用功能:");
        printf("\n 请输入您要选择的操作序号，按回车键确认：");
        int choose;
        scanf("%d",&choose);
        switch(choose)
        {
                case 1:Cin();break;
                case 2:write();break;
                case 3:statistic();break;
                case 4:exit(0);break;
                default:printf("输入错误，请输入列表中存在的序号！\n ");getchar();getchar();
        }
}
void Cin()//写入文本
{
        system("cls");
        system("title 欢迎使用统计文本小程序");//控制窗口显示标题内容
    FILE *fp;
    char ch;
    if((fp=fopen("123.txt","r"))==NULL){
        printf("Open the file failure...\n");
        exit(0);
    }
    while((ch=fgetc(fp))!=EOF)
        printf("%c",ch);
        puts("");
   printf("按任意键返回主菜单\n");
   fclose(fp);
   getchar();getchar();
}
void write()//写入文档
{
        system("cls");
        system("title 欢迎使用统计文本小程序");//控制窗口显示标题内容
        FILE *fp;
        if((fp=fopen("123.txt","w"))==NULL){
                printf("Open the file failure...\n");
                exit(0);
        }
        char s[100000];
        printf("请输入要写入文档的内容：");
        scanf("%s",s);
        fprintf(fp,"%s",s);
        fclose(fp);
        printf("已成功写入~按任意键返回主菜单\n");
        fclose(fp);
        getchar();getchar();
}
void statistic()//统计
{
        system("cls");
        system("title 欢迎使用统计文本小程序");//控制窗口显示标题内容
    char s[100000],s1[100],ch;
    FILE *fp;
    int n=0,m=0;
    if((fp=fopen("123.txt","r"))==NULL)
    {
        printf("Open the file failure...\n");
        exit(0);
    }
    while((ch=fgetc(fp))!=EOF)
    {

        if(ch<0)
        {
                int f=1;
                for(int i=0;i<n;i++)
                {
                        if(s[i]==ch)
                                f=0;
                }
                if(f){
                        s[n++]=ch;
                }
        }
        else
        {
                int f=1;
                for(int i=0;i<m;i++)
                {
                        if(s1[i]==ch)
                                f=0;
                }
                if(f)
                {
                        s1[m++]=ch;
                }
        }

    }
    s[n]='\0';
    s1[m]='\0';
    printf("经统计得不相同的汉字为：\n");
    printf("%s\n",s);
    printf("经统计得不相同的字符为：\n");
    printf("%s\n",s1);
    printf("按任意键返回主菜单\n");
    getchar();
    getchar();
}

int main(void)
{
        system("cls");
        system("title 欢迎使用统计文本小程序");//控制窗口显示标题内容
    while(1)
    {
        menu();
    }
}
